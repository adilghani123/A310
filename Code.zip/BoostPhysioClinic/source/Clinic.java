import java.util.ArrayList;
import java.util.List;

public class Clinic {
    private List<Patient> patients;
    private List<Physiotherapist> physiotherapists;

    public Clinic() {
        this.patients = new ArrayList<>();
        this.physiotherapists = new ArrayList<>();
    }

    // Add Patient
    public void addPatient(Patient patient) {
        patients.add(patient);
    }

    // Remove Patient
    public void removePatient(Patient patient) {
        patients.remove(patient);
    }

    // Book Appointment
    public void bookAppointment(Patient patient, Physiotherapist physiotherapist, String date, String time) {
        Appointment appointment = new Appointment(date, time, "booked", physiotherapist, patient);
        patient.addAppointment(appointment);
        physiotherapist.addSchedule(appointment);
    }

    // Cancel Appointment
    public void cancelAppointment(Patient patient, Appointment appointment) {
        appointment.setStatus("cancelled");
    }

    // Generate Report
    public void generateReport() {
        for (Physiotherapist physiotherapist : physiotherapists) {
            System.out.println("Physiotherapist: " + physiotherapist.getName());
            for (Appointment appointment : physiotherapist.getSchedule()) {
                System.out.println("Treatment: " + appointment.getTime() + " Status: " + appointment.getStatus());
            }
        }
    }

    public List<Patient> getPatients() {
        return patients;
    }
}

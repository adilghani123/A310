public class BoostPhysioClinicApp {
    public static void main(String[] args) {
        Clinic clinic = new Clinic();
        Patient patient = new Patient(1, "John Doe", "123 Main St", "555-1234");
        Physiotherapist physiotherapist = new Physiotherapist(1, "Dr. Smith", List.of("Massage", "Rehabilitation"));

        // Add Patient
        clinic.addPatient(patient);
        
        // Book Appointment
        clinic.bookAppointment(patient, physiotherapist, "2025-05-01", "10:00-11:00");

        // Generate Report
        clinic.generateReport();
    }
}

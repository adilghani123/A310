import java.util.List;

public class Patient {
    private int ID;
    private String name;
    private String address;
    private String phoneNumber;
    private List<Appointment> appointments;

    // Constructor, getters, and setters
    public Patient(int ID, String name, String address, String phoneNumber) {
        this.ID = ID;
        this.name = name;
        this.address = address;
        this.phoneNumber = phoneNumber;
    }

    public void addAppointment(Appointment appointment) {
        this.appointments.add(appointment);
    }

    public List<Appointment> getAppointments() {
        return appointments;
    }
}

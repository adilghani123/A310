import java.util.List;

public class Physiotherapist {
    private int ID;
    private String name;
    private List<String> areaOfExpertise;
    private List<Appointment> schedule;

    // Constructor, getters, and setters
    public Physiotherapist(int ID, String name, List<String> areaOfExpertise) {
        this.ID = ID;
        this.name = name;
        this.areaOfExpertise = areaOfExpertise;
    }

    public int getID() {
        return ID;
    }

    public String getName() {
        return name;
    }

    public List<Appointment> getSchedule() {
        return schedule;
    }

    public void addSchedule(Appointment appointment) {
        this.schedule.add(appointment);
    }
}

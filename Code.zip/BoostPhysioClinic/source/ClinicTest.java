import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ClinicTest {
    @Test
    void testAddPatient() {
        Clinic clinic = new Clinic();
        Patient patient = new Patient(1, "John Doe", "123 Main St", "555-1234");
        clinic.addPatient(patient);
        assertEquals(1, clinic.getPatients().size());
    }

    @Test
    void testBookAppointment() {
        Clinic clinic = new Clinic();
        Patient patient = new Patient(1, "John Doe", "123 Main St", "555-1234");
        Physiotherapist physiotherapist = new Physiotherapist(1, "Dr. Smith", List.of("Massage"));
        clinic.addPatient(patient);
        clinic.bookAppointment(patient, physiotherapist, "2025-05-01", "10:00-11:00");
        assertEquals(1, patient.getAppointments().size());
    }

    @Test
    void testCancelAppointment() {
        Clinic clinic = new Clinic();
        Patient patient = new Patient(1, "John Doe", "123 Main St", "555-1234");
        Physiotherapist physiotherapist = new Physiotherapist(1, "Dr. Smith", List.of("Massage"));
        clinic.addPatient(patient);
        clinic.bookAppointment(patient, physiotherapist, "2025-05-01", "10:00-11:00");
        Appointment appointment = patient.getAppointments().get(0);
        clinic.cancelAppointment(patient, appointment);
        assertEquals("cancelled", appointment.getStatus());
    }
}

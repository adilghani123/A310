import java.util.List;

public class Treatment {
    private String name;
    private Physiotherapist physiotherapist;
    private List<String> availableTimes;

    // Constructor, getters, and setters
    public Treatment(String name, Physiotherapist physiotherapist, List<String> availableTimes) {
        this.name = name;
        this.physiotherapist = physiotherapist;
        this.availableTimes = availableTimes;
    }
}
s